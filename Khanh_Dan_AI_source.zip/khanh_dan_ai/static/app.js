const chat = document.querySelector("#chat");
const form = document.querySelector("#form");
const input = document.querySelector("#message");
const sendBtn = document.querySelector("#sendBtn");
const welcome = document.querySelector("#welcome");
let history = [];

function addMessage(role, content) {
  welcome?.remove();
  const row = document.createElement("div");
  row.className = `message ${role}`;
  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.textContent = role === "user" ? "BẠN" : "KD";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = content;
  row.append(avatar, bubble);
  chat.append(row);
  chat.scrollTop = chat.scrollHeight;
  return bubble;
}

async function send(text) {
  const message = text.trim();
  if (!message || sendBtn.disabled) return;
  addMessage("user", message);
  const prior = history.slice(-12);
  history.push({role:"user", content:message});
  input.value = "";
  input.style.height = "auto";
  sendBtn.disabled = true;
  const pending = addMessage("assistant", "Khanh Đan AI đang suy nghĩ...");
  try {
    const response = await fetch("/api/chat", {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({message, history:prior})
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || "Không thể kết nối máy chủ.");
    pending.textContent = data.reply || "Mình chưa tạo được câu trả lời.";
    history.push({role:"assistant", content:pending.textContent});
  } catch (err) {
    pending.textContent = "Xin lỗi, " + err.message;
    history.pop();
  } finally {
    sendBtn.disabled = false;
    input.focus();
    chat.scrollTop = chat.scrollHeight;
  }
}
form.addEventListener("submit", e => { e.preventDefault(); send(input.value); });
input.addEventListener("input", () => { input.style.height="auto"; input.style.height=Math.min(input.scrollHeight,160)+"px"; });
input.addEventListener("keydown", e => { if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();form.requestSubmit();} });
document.querySelectorAll(".suggestion").forEach(b=>b.addEventListener("click",()=>send(b.textContent)));
document.querySelector("#clearBtn").addEventListener("click",()=>{
  history=[]; chat.innerHTML="";
  const panel=document.createElement("div"); panel.className="welcome"; panel.id="welcome";
  panel.innerHTML='<div class="welcome-logo">KD</div><h2>Xin chào! Mình là Khanh Đan AI</h2><p>Bạn muốn hỏi điều gì hôm nay?</p>';
  chat.append(panel); input.focus();
});
if ("serviceWorker" in navigator) window.addEventListener("load",()=>navigator.serviceWorker.register("/static/sw.js").catch(()=>{}));
